/**
 * SYST 17796 Project Base code.
 * Students can modify and extend to implement their game.
 * Add your name as an author and the date!
 */
package main.java.com.mycompany.wargame_group7;

import main.java.com.mycompany.wargame_group7.Card;
import java.util.ArrayList;

/**
 * The class that models your game. You should create a more specific child of this class and instantiate the methods
 * given.
 *
 * @author GameMaster_Group7 
 * Date = 2025 - 02 - 13
 */
public class Game {

    public static void main(String[] args) {
        // Instantiate a group of cards
        GroupOfCards deck = new GroupOfCards();
        deck.populateDeck();
        deck.shuffle();

        // Add players
        Player player1 = new Player("Player 1");
        Player player2 = new Player("Player 2");

        // Distribute cards to players
        for (int i = 0; i < 26; i++) {
            player1.draw(deck);
            player2.draw(deck);
        }

        // Start the game
        for (int i = 0; i < 26; i++) {
            Card card1 = player1.flipCard();
            Card card2 = player2.flipCard();

            // Display the cards played by each player
            System.out.println(player1.getName() + " plays: " + card1);
            System.out.println(player2.getName() + " plays: " + card2);

            // Determine the winner of the round
            if (card1.getValue() > card2.getValue()) {
                player1.incrementScore();
                System.out.println(player1.getName() + " wins the round!");
            } else if (card1.getValue() < card2.getValue()) {
                player2.incrementScore();
                System.out.println(player2.getName() + " wins the round!");
            } else {
                System.out.println("It's a draw!");
            }
        }

        // Display final scores
        System.out.println("Final Score:");
        System.out.println(player1.getName() + ": " + player1.getScore());
        System.out.println(player2.getName() + ": " + player2.getScore());

        // Determine the winner of the game
        if (player1.getScore() > player2.getScore()) {
            System.out.println(player1.getName() + " wins the game!");
        } else if (player1.getScore() < player2.getScore()) {
            System.out.println(player2.getName() + " wins the game!");
        } else {
            System.out.println("It's a tie!");
        }
    }
}
