
package main.java.com.mycompany.wargame_group7;

import main.java.com.mycompany.wargame_group7.GroupOfCards;
import main.java.com.mycompany.wargame_group7.Card;
import java.util.ArrayList;

/**
 * A class that models each Player in the game. Players have an identifier, which should be unique.
 *
 * @author GameMaster_Group7 
 * Date = 2025 - 03 - 20
 */
public class Player {
    private String name;
    private int score;
    private ArrayList<Card> hand;

    public Player(String name) {
        this.name = name;
        this.score = 0;
        this.hand = new ArrayList<>();
    }

    public void draw(GroupOfCards deck) {
        Card card = deck.drawCard();
        if (card != null) {
            hand.add(card);
        }
    }

    public Card flipCard() {
        if (!hand.isEmpty()) {
            return hand.remove(0);
        } else {
            return null; // Return null if the player's hand is empty
        }
    }

    public void incrementScore() {
        score++;
    }

    public String getName() {
        return name;
    }

    public int getScore() {
        return score;
    }
}
