/**
 * SYST 17796 Project Base code.
 * Students can modify and extend to implement their game.
 * Add your name as an author and the date!
 */
package main.java.com.mycompany.wargame_group7;

import main.java.com.mycompany.wargame_group7.Card;
import java.util.ArrayList;
import java.util.Collections;

/**
 * A concrete class that represents any grouping of cards for a Game. HINT, you might want to subclass this more than
 * once. The group of cards has a maximum size attribute which is flexible for reuse.
 *
 *@author GameMaster_Group7 
 * Date = 2025 - 03 - 20
 */
public class GroupOfCards {
    private final ArrayList<Card> cards;

    public GroupOfCards() {
        cards = new ArrayList<>();
    }

    public void populateDeck() {
        String[] suits = {"Spades", "Hearts", "Clubs", "Diamonds"};
        for (String suit : suits) {
            for (int value = 2; value <= 14; value++) {
                String name;
                switch (value) {
                    case 11:
                        name = "Jack";
                        break;
                    case 12:
                        name = "Queen";
                        break;
                    case 13:
                        name = "King";
                        break;
                    case 14:
                        name = "Ace";
                        break;
                    default:
                        name = String.valueOf(value);
                        break;
                }
                cards.add(new Card(value, name + " of " + suit) {});
            }
        }
    }

    public void shuffle() {
        Collections.shuffle(cards);
    }

    public Card drawCard() {
        if (!cards.isEmpty()) {
            return cards.remove(0);
        } else {
            return null; // Return null if the deck is empty
        }
    
}}